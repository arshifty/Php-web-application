
<html>
<head>
<meta http-equiv="refresh" content="30">
<meta name="viewport" content="width=device-width,initial-scale=1">
</head>

<body background="../background/b.jpg" >
 <h1 align="center">  Online medical service for Kurigram. </h1>

<ol style="font-size:20px;">
<li><a href="../index.php"> হোম পেজ </a></li>
<li><a href="blood.php">রক্ত অনুসন্ধান  </a></li>
<li><a href="ambulence.php"> অ্যাম্বুলেন্স  অনুসন্ধান   </a></li>
<li><a href="medical.php"> মেডিকেল / ক্লিনিক / ডায়াগনস্টিক সেন্টার  </a></li>
</ol>


</body>
</html>