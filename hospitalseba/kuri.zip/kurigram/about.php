
<html>
<head>

<meta name="viewport" content="width=device-width,initial-scale=1">
</head>

<body background="../background/a.jpg" >
<br>
Go to <a href="../index.php">Home </a><br>
<h3>About Developer </h3>
<h4 style="color:Tomato;">If you face any problem while playing this application please communicate with me .</h4>
<table cellspacing="5" cellpadding="5">
<tr>
<td> Name </td>
<td> Ashif Rahman . </td>
</tr>

<tr>
<td>Contact </td>
<td> <b> 01521466521  </b></td>
</tr>

<tr>
<td> Current Address</td>
<td> Sere-bangla hall , Karnakathi , university of Barisal. </td>
</tr>

<tr>
<td>Local Address </td>
<td> Paik-para , krisnopur , Kurigram.  </td>
</tr>

<tr>
<td> Academic background</td>
<td> 

<b>School : </b>Kurigram Govt. High School , Kurigram. <br>
<b>College :</b> Police Lines School & College , Rangpur . <br>
<b>University :</b> Studying at Computer Science & Engineering , University of Barisal.<br>
</td>
</tr>

<tr>
<td>E-mail</td>
<td> arshifty@gmail.com </td>
</tr>


</table>


</body>
</html>